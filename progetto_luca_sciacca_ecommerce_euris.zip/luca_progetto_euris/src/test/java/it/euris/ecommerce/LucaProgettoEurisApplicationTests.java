package it.euris.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LucaProgettoEurisApplicationTests {

	@Test
	void contextLoads() {
	}

}
