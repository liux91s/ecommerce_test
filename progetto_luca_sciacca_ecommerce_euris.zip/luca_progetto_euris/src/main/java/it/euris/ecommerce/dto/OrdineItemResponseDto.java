package it.euris.ecommerce.dto;

public class OrdineItemResponseDto {

}
