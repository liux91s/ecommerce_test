package it.euris.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LucaProgettoEurisApplication {

	public static void main(String[] args) {
		SpringApplication.run(LucaProgettoEurisApplication.class, args);
	}

}
