package it.euris.ecommerce.dto;

import lombok.Data;

@Data
public class OrdineItemDto {
	private Long idProdotto;
	private Integer quantita;

}
